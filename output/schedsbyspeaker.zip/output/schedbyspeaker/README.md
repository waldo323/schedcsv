Hot to import a csv into Google Calender
========

Instructions summary: 
   * download/save your csv
   * create a new calendar
   * import csv into new calendar


Detail instructions:
========
Download/save your csv
   *

 
Create a new calendar
   * 


Import csv into new calendar
   *
 
   
